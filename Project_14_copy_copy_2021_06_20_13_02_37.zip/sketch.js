var sword,swordImage;

//game states
var PLAY = 1;
var END = 0;
var gameState = 1;

var score;
var fruitGroup,fruit1,fruit2,fruit3,fruit4;
var fruit1Image,fruit2Image,fruit3Image,fruit4Image;
var aliengroup,alien1,alien2;
var alien1Image,alien2Image;

function preload(){
    sowrdImage = loadImage("sowrd.png");
    fruit1Image = loadImage("fruit1.png");
    fruit2Image = loadImage("fruit2.png");
    fruit3Image = loadImage("fruit3.png");
    fruit4Image = loadImage("fruit4.png");
  
}

function setup(){
  createCanvas(600,600);
  
  //creating sowrd
  sowrd = createSprite(40,200,20,20);
  sowrd.addImage(swordImage);
  sword.scale = 0.7
  
  //score and group variables 
  score = 0;
  fruitGroup = createGroup();
  alienGroup = createGroup();
}

function draw(){
//calling alien and fruit function 
  alien();
  fruit9();
  
  //making sword to move with mouses x and y position
  
}

function fruit(){
  fruitGroup.add(fruit);
  //increasing score if sword touches fruitgroup
  if(fruitGroup.isTouching(sword)){
    fruitGroup.destroyEach();
  }

}